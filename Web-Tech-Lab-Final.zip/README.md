# 🚀 Web Technology Lab Experiments (1–10)

## 📌 Description
This repository contains complete implementation of Web Technology Lab experiments using:
- HTML, CSS, JavaScript
- Bootstrap
- Node.js
- Express.js
- Java (JDBC, Servlets)
- XML (DTD, XSD)

---

## 📂 Experiments List
1. Shopping Cart (HTML, CSS)
2. Bootstrap Enhancement
3. JavaScript Validation
4. Weather App (API + ES6)
5. JDBC CRUD
6. XML Validation
7. Servlet + Database
8. Session Tracking
9. Node.js Server
10. Express REST API

---

## ▶️ How to Run

### Frontend
Open HTML files in browser

### Node
node server.js

### Express
npm install express
node app.js

### Java
Compile and run using JDK

---

## 👤 Author
Mohammed Junaid
